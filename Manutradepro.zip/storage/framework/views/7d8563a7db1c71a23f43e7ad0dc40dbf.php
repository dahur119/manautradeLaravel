
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['route', 'text', 'icon' => 'flaticon-plus', 'class' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['route', 'text', 'icon' => 'flaticon-plus', 'class' => '']); ?>
<?php foreach (array_filter((['route', 'text', 'icon' => 'flaticon-plus', 'class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="button-box">
    <a href="<?php echo e($route); ?>" class="theme-btn btn-style-three clearfix <?php echo e($class); ?>">
        <span class="btn-wrap">
            <span class="text-one"><?php echo e($text); ?></span>
            <span class="text-two"><?php echo e($text); ?></span>
        </span>
        <span class="plus <?php echo e($icon); ?>"></span>
    </a>
</div><?php /**PATH C:\laragon\www\Manutradepro\resources\views/components/button.blade.php ENDPATH**/ ?>