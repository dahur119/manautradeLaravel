
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'backgroundImage' => 'images/background/9.jpg', // Default background image
    'breadcrumbs' => [], // Array of breadcrumbs
    'title' => 'About Us', // Default title
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'backgroundImage' => 'images/background/9.jpg', // Default background image
    'breadcrumbs' => [], // Array of breadcrumbs
    'title' => 'About Us', // Default title
]); ?>
<?php foreach (array_filter(([
    'backgroundImage' => 'images/background/9.jpg', // Default background image
    'breadcrumbs' => [], // Array of breadcrumbs
    'title' => 'About Us', // Default title
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<section class="page-title" style="background-image: url(<?php echo e(asset($backgroundImage)); ?>)">
    <div class="auto-container">
        
        <ul class="bread-crumb clearfix">
            <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php if(isset($breadcrumb['route'])): ?>
                        <a href="<?php echo e($breadcrumb['route']); ?>"><?php echo e($breadcrumb['label']); ?></a>
                    <?php else: ?>
                        <?php echo e($breadcrumb['label']); ?>

                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        
        <h2><?php echo e($title); ?></h2>
    </div>
</section><?php /**PATH C:\laragon\www\Manutradepro\resources\views/components/page-title.blade.php ENDPATH**/ ?>