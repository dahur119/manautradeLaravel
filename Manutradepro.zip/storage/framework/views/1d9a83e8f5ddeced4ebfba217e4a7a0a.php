
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'image' => 'images/resource/team-6.jpg', // Default image
    'name' => 'Erl Winnson Pillecer Salud', // Default name
    'designation' => 'Director - ManutradePro Philippines', // Default designation
    'facebook' => '#', // Default Facebook link
    'instagram' => '#', // Default Instagram link
    'dribbble' => '#', // Default Dribbble link
    'route' => '#', // Default profile link
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'image' => 'images/resource/team-6.jpg', // Default image
    'name' => 'Erl Winnson Pillecer Salud', // Default name
    'designation' => 'Director - ManutradePro Philippines', // Default designation
    'facebook' => '#', // Default Facebook link
    'instagram' => '#', // Default Instagram link
    'dribbble' => '#', // Default Dribbble link
    'route' => '#', // Default profile link
]); ?>
<?php foreach (array_filter(([
    'image' => 'images/resource/team-6.jpg', // Default image
    'name' => 'Erl Winnson Pillecer Salud', // Default name
    'designation' => 'Director - ManutradePro Philippines', // Default designation
    'facebook' => '#', // Default Facebook link
    'instagram' => '#', // Default Instagram link
    'dribbble' => '#', // Default Dribbble link
    'route' => '#', // Default profile link
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="team-block-two col-lg-3 col-md-6 col-sm-12">
    <div class="inner-box wow fadeInLeft" data-wow-delay="150ms" data-wow-duration="1500ms">
        <div class="image">
            <div class="social-box">
                <a href="<?php echo e($facebook); ?>" class="fa fa-facebook"></a>
                <a href="<?php echo e($instagram); ?>" class="fa fa-instagram"></a>
                <a href="<?php echo e($dribbble); ?>" class="fa fa-dribbble"></a>
            </div>
            <a href="<?php echo e($route); ?>"><img src="<?php echo e(asset($image)); ?>" alt="<?php echo e($name); ?>" /></a>
        </div>
        <div class="lower-content">
            <h4><a href="<?php echo e($route); ?>"><?php echo e($name); ?></a></h4>
            <div class="designation"><?php echo e($designation); ?></div>
            <a class="plus-icon flaticon-plus" href="<?php echo e($route); ?>"></a>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\Manutradepro\resources\views/components/team-member.blade.php ENDPATH**/ ?>