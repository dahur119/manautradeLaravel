<!DOCTYPE html>
<html>

<!-- Mirrored from html.themexriver.com/industo/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 11 Dec 2024 20:24:40 GMT -->
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<!-- <div class="cursor"></div> -->


<div class="page-wrapper">


    

	<!-- Preloader End -->

    <?php echo $__env->make('layouts.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   
	<!-- scrollToTop start -->
	<div class="progress-wrap active-progress">
		<svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
		<path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919px, 307.919px; stroke-dashoffset: 228.265px;"></path>
		</svg>
	</div>


    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (isset($component)) { $__componentOriginal8b54caccbdedc8030792c13949386bbd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b54caccbdedc8030792c13949386bbd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-title','data' => ['backgroundImage' => 'images/background/9.jpg','breadcrumbs' => [
        ['label' => 'Home', 'route' => route('index')],
        ['label' => 'Services'],
    ],'title' => 'Base Oil']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['backgroundImage' => 'images/background/9.jpg','breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['label' => 'Home', 'route' => route('index')],
        ['label' => 'Services'],
    ]),'title' => 'Base Oil']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b54caccbdedc8030792c13949386bbd)): ?>
<?php $attributes = $__attributesOriginal8b54caccbdedc8030792c13949386bbd; ?>
<?php unset($__attributesOriginal8b54caccbdedc8030792c13949386bbd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b54caccbdedc8030792c13949386bbd)): ?>
<?php $component = $__componentOriginal8b54caccbdedc8030792c13949386bbd; ?>
<?php unset($__componentOriginal8b54caccbdedc8030792c13949386bbd); ?>
<?php endif; ?>

<div class="sidebar-page-container">
		<div class="pattern-layer" style="background-image:url(images/background/pattern-25.png)"></div>
    	<div class="auto-container">
        	<div class="row clearfix">
				
				<!-- Sidebar Side -->
                <div class="sidebar-side left-sidebar col-lg-4 col-md-12 col-sm-12">
                	<aside class="sidebar sticky-top">
						
						<!-- Service Widget -->
						<div class="sidebar-widget service-widget">
							<div class="widget-content">
								<div class="sidebar-title">
									<h4>All Service</h4>
								</div>
								<ul class="service-list">
									<?php echo $__env->make('components.service-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								</ul>
							</div>
						</div>
						
						<!-- Download Widget -->
					
						
						<!-- Support Widget -->
						
					</aside>
				</div>
				
				<!-- Content Side -->
                <div class="content-side right-sidebar col-lg-8 col-md-12 col-sm-12">
					<div class="service-detail">
						<div class="inner-box">
							<div class="image">
								<img src="images/resource/news-11.jpg" alt="" />
							</div>
							<div class="lower-content">
								<h3>Base Oil</h3>
								<p>Base oils are the fundamental building blocks of lubricants, essential for reducing friction and wear in engines and machinery. They are derived from the refining of crude oil or through advanced chemical processes to meet specific industry standards. These oils serve as the primary fluid in various applications, including motor oils, gear oils, hydraulic fluids, and industrial lubricants.</p>
								<p>The quality of base oils directly influences the performance and longevity of the equipment they lubricate. With different refining methods and chemical compositions, base oils are categorized into groups that determine their suitability for various applications. Group I oils are produced through traditional refining methods, suitable for standard applications, while Group II and III oils offer higher purity, performance, and extended protection for modern, high-performance engines. Group IV and V base oils, which are synthetic, provide superior stability and performance in extreme conditions, delivering optimal protection in demanding industrial environments.
								</p>

								<p>At Manutrade Pro Solutions LTD, we offer a wide range of premium base oils, including SN150, SN500, SN900, and BS150, designed to meet the diverse needs of industries from automotive to heavy machinery. Our base oils are sourced from reputable refineries, ensuring exceptional quality and reliability for your lubrication needs. By choosing our base oils, you are investing in solutions that promote smoother operations, reduce maintenance costs, and enhance the efficiency and durability of your equipment.
								</p>
								<!-- Gallery Images -->
								
								<!-- End Gallery Images -->
								
								
								<!-- End Accordion Outer -->
								
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>


<?php echo $__env->make('layouts.main-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\laragon\www\Manutradepro\resources\views/base-oil.blade.php ENDPATH**/ ?>