
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'icon' => 'flaticon-oil-pump', // Default icon
    'title' => 'Oil and Gas Supply', // Default title
    'description' => 'Default description.', // Default description
    'route' => '', // Default route
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'icon' => 'flaticon-oil-pump', // Default icon
    'title' => 'Oil and Gas Supply', // Default title
    'description' => 'Default description.', // Default description
    'route' => '', // Default route
]); ?>
<?php foreach (array_filter(([
    'icon' => 'flaticon-oil-pump', // Default icon
    'title' => 'Oil and Gas Supply', // Default title
    'description' => 'Default description.', // Default description
    'route' => '', // Default route
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="service-block-three col-lg-3 col-md-6 col-sm-12">
    <div class="inner-box wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
        <div class="color-layer">
            <span class="color-one"></span>
            <span class="color-two"></span>
            <span class="color-three"></span>
            <span class="color-four"></span>
        </div>
        <div class="icon-box">
            <span class="icon <?php echo e($icon); ?>"></span>
        </div>
        <h5><a href="<?php echo e($route); ?>"><?php echo e($title); ?></a></h5>
        <div class="text"><?php echo e($description); ?></div>
        <a class="plus-icon flaticon-plus" href="<?php echo e($route); ?>"></a>
    </div>
</div><?php /**PATH C:\laragon\www\Manutradepro\resources\views/components/service-block.blade.php ENDPATH**/ ?>