<div class="widgets-section">
				<div class="row clearfix">
					
					<!-- Big Column -->
					<div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!-- Footer Column -->
							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
								<div class="footer-widget logo-widget">
									<div class="logo">
										<a href="index.html"><img src="images/logo-3.png" alt="" /></a>
									</div>
									<div class="text">At Manutrade Pro Solutions LTD, we redefine supplier relationships by offering innovative, sustainable, and reliable industrial products.</div>
									<ul class="social-box">
										<li><a href="#" class="fa fa-facebook"></a></li>
										<li><a href="#" class="fa fa-twitter"></a></li>
										<li><a href="#" class="fa fa-dribbble"></a></li>
										<li><a href="#" class="fa fa-behance"></a></li>
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
							

							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
								<div class="footer-widget newsletter-widget">
									<h5>Newsletter</h5>
									<div class="widget-content">
										<div class="text">Subscribe our Newsletter to get Our Latest updates & news</div>
										<!-- Email Box -->
										<div class="email-box-two">
											<form method="post" action="#">
												<div class="form-group">
													<input type="email" name="search-field" value="" placeholder="Enter Email Address" required>
													<button type="submit"><span class="icon flaticon-send"></span></button>
												</div>
											</form>
										</div>
										<div class="lower-text">*** We Never gonna spamming</div>
									</div>
								</div>
							</div>
							
						</div>
					</div>
					
					<!-- Big Column -->
					<div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!-- Footer Column -->

							
							
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget contact-widget">
									<h5>Get In Touch</h5>
									<ul class="contact-list">
										<li>
											<span class="icon flaticon-telephone"></span> 
											Phone Number
											<a href="mailto:+90-845-758-145">+234-810 093 2220</a>
										</li>
										<li>
											<span class="icon flaticon-email"></span> 
											Email Address
											<a href="mailto:industo@gmail.com">info@manutradepro.com
											</a>
										</li>
										<li>
											<span class="icon flaticon-home"></span> 
											Office Address
											<a href="#">Cluster C, Gold Crest Executive,
												Jumeirah Lake Towers, Dubai,
												United Arab Emirates
												</a>
										</li>
									</ul>
								</div>
							</div>


							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget contact-widget">
									<h5>Links</h5>
									<ul class="contact-lists">
									<li><a href="<?php echo e(route('index')); ?>">Home</a>
										
										</li>
										<li ><a href="<?php echo e(route('about')); ?>">About</a>
											
										</li>
										<li><a href="<?php echo e(route('services')); ?>">Services</a>
										
										</li>
										<li><a href="<?php echo e(route('product')); ?>">Product</a>
									

									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div><?php /**PATH C:\laragon\www\Manutradepro\resources\views/layouts/footer.blade.php ENDPATH**/ ?>