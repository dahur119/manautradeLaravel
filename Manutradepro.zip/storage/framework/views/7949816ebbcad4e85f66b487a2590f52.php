
   
    <li class="current"><a href="<?php echo e(route('base-oil')); ?>">Base Oil</a></li>
    <li><a href="<?php echo e(route('premium-motor-spirit')); ?>">Premium Motor Spirit (PMS)</a></li>
    <li><a href="<?php echo e(route('automotive-gas-oil')); ?>">Automotive Gas Oil (AGO)</a></li>
    <li><a href="<?php echo e(route('high-density-polyethylene')); ?>">High-Density Polyethylene (HDPE)</a></li>
    <li><a href="<?php echo e(route('low-density-polyethylene')); ?>">Low-Density Polyethylene (LDPE)</a></li>
    <li><a href="<?php echo e(route('polypropylene')); ?>">Polypropylene (PP)</a></li>
    <li><a href="<?php echo e(route('polyethylene-terephthalate')); ?>">Polyethylene Terephthalate (PET)</a></li>
    <li><a href="<?php echo e(route('blow-molding')); ?>">Blow Molding Accessories</a></li>
    <li><a href="<?php echo e(route('low-pour-fuel-oil')); ?>">Low Pour Fuel Oil (LPFO)</a></li>
    <li><a href="<?php echo e(route('marine-diesel-oil')); ?>">Marine Diesel Oil (MDO)</a></li>
    <li><a href="<?php echo e(route('recycling-machine')); ?>">Recycling Machines</a></li>
    <li><a href="<?php echo e(route('used-lubricants')); ?>">Used Lubricants</a></li>
<?php /**PATH C:\laragon\www\Manutradepro\resources\views/components/service-list.blade.php ENDPATH**/ ?>