<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/appear.js"></script>
<script src="js/appear-2.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/tilt.jquery.min.js"></script>
<script src="js/jquery.paroller.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/odometer.js"></script>
<script src="js/slick.js"></script>
<script src="js/backToTop.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/cursor-script.js"></script>
<script src="js/script.js"></script>

<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->

</body>

<!-- Mirrored from html.themexriver.com/industo/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 11 Dec 2024 20:33:53 GMT -->
</html><?php /**PATH C:\laragon\www\Manutradepro\resources\views/layouts/script.blade.php ENDPATH**/ ?>