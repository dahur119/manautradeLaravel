<!DOCTYPE html>
<html>

<!-- Mirrored from html.themexriver.com/industo/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 11 Dec 2024 20:24:40 GMT -->
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<!-- <div class="cursor"></div> -->


<div class="page-wrapper">


    

	<!-- Preloader End -->

    <?php echo $__env->make('layouts.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   
	<!-- scrollToTop start -->
	<div class="progress-wrap active-progress">
		<svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
		<path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919px, 307.919px; stroke-dashoffset: 228.265px;"></path>
		</svg>
	</div>


    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (isset($component)) { $__componentOriginal8b54caccbdedc8030792c13949386bbd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b54caccbdedc8030792c13949386bbd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-title','data' => ['backgroundImage' => 'images/background/9.jpg','breadcrumbs' => [
        ['label' => 'Home', 'route' => route('index')],
        ['label' => 'Contact Us'],
    ],'title' => 'Contact Us']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['backgroundImage' => 'images/background/9.jpg','breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['label' => 'Home', 'route' => route('index')],
        ['label' => 'Contact Us'],
    ]),'title' => 'Contact Us']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b54caccbdedc8030792c13949386bbd)): ?>
<?php $attributes = $__attributesOriginal8b54caccbdedc8030792c13949386bbd; ?>
<?php unset($__attributesOriginal8b54caccbdedc8030792c13949386bbd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b54caccbdedc8030792c13949386bbd)): ?>
<?php $component = $__componentOriginal8b54caccbdedc8030792c13949386bbd; ?>
<?php unset($__componentOriginal8b54caccbdedc8030792c13949386bbd); ?>
<?php endif; ?>


<section class="contact-page-section">
		<div class="auto-container">
			<!-- Sec Title Three -->
			<div class="sec-title-three centered">
				<h2>Office Near You.</h2>
			</div>
			
			<div class="row clearfix">
			
				<!-- Location Block -->
				<div class="location-block col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="content">
							<span class="icon flaticon-message"></span>
							<strong>Email Address</strong>
							Sent mail asap anytime
							info@manutradepro.com<br>
						</div>
					
					
					</div>
				</div>
				
				<!-- Location Block -->
				<div class="location-block col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="content">
							<span class="icon flaticon-call"></span>
							<strong>Phone Number</strong>
							call us asap anytime: <br>
							+234-810 093 2220
						</div>
						
					</div>
				</div>
				
				<!-- Location Block -->
				<div class="location-block col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="content">
							<span class="icon flaticon-home"></span>
							<strong>Office Address</strong>
							Sent mail asap anytime
						</div>
						Cluster C, Gold Crest Executive, Jumeirah <br> Lake Towers, Dubai, United Arab Emirates
					
					</div>
				</div>
				
			</div>
			
		</div>

	</section>


    <div class="contact-form-section">
		<div class="pattern-layer" style="background-image:url(images/background/pattern-25.png)"></div>
    	<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title alternate centered">
				<div class="title">Submit Question</div>
				<h2>Needs Help? Let’s Get in Touch</h2>
			</div>
			<div class="inner-container">
				
				<!-- Contact Form -->
				<div class="contact-form">
					
					<!-- Contact Form -->
					<form method="post" action="<?php echo e(route('contact.store')); ?>" id="contact-form">
						<?php echo csrf_field(); ?>
						<div class="row clearfix">
							<div class="col-lg-6 col-md-6 col-sm-12 form-group">
								<input type="text" name="name" placeholder="Name" required>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-12 form-group">
								<input type="email" name="email" placeholder="Your Email" required>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-12 form-group">
								<input type="text" name="phone" placeholder="Your Phone" required>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-12 form-group">
								<input type="text" name="title" placeholder="Your Subject" required>
							</div>
							
							<div class="col-lg-12 col-md-12 col-sm-12 form-group">
								<textarea name="message" placeholder="Message" required></textarea>
							</div>
							
							<div class="col-lg-12 col-md-12 col-sm-12 form-group">
								<button class="theme-btn btn-style-eight clearfix" type="submit">
									<span class="btn-wrap">
										<span class="text-one">Send Message</span>
										<span class="text-two">Send Message</span>
									</span>
								</button>
							</div>
						</div>
					</form>
						
				</div>
				<!--End Contact Form -->
				
			</div>
		</div>
	</div>
	<!-- End Location Section -->
	
	<!-- Map Column -->
	
	<!-- End Map Column -->
	
	<!-- Contact Form Section -->
    

<?php echo $__env->make('layouts.main-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\laragon\www\Manutradepro\resources\views/contact.blade.php ENDPATH**/ ?>