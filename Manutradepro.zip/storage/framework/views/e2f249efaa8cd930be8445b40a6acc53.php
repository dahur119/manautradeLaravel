<div class="loader-wrap">
		<div class="preloader">
			<div class="preloader-close">x</div>
			<div id="handle-preloader" class="handle-preloader">
				<div class="animation-preloader">
					<div class="spinner"></div>
					<div class="txt-loading">
						<span data-text-preloader="M" class="letters-loading">
							M
						</span>
						<span data-text-preloader="A" class="letters-loading">
							A
						</span>
						<span data-text-preloader="N" class="letters-loading">
							N
						</span>
						<span data-text-preloader="U" class="letters-loading">
							U
						</span>
						<span data-text-preloader="T" class="letters-loading">
							T
						</span>
						<span data-text-preloader="R" class="letters-loading">
							R
						</span><span data-text-preloader="A" class="letters-loading">
							A
						</span>
						<span data-text-preloader="D" class="letters-loading">
							D
						</span>
						<span data-text-preloader="E" class="letters-loading">
							E
						</span>
						<span data-text-preloader="P" class="letters-loading">
							P
						</span>
						<span data-text-preloader="R" class="letters-loading">
							R
						</span>
						<span data-text-preloader="O" class="letters-loading">
							O
						</span>
					</span>
					

					</div>
				</div>  
			</div>
		</div>
	</div><?php /**PATH C:\laragon\www\Manutradepro\resources\views/layouts/preloader.blade.php ENDPATH**/ ?>