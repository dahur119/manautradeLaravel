
   
    <li class="current"><a href="{{ route('base-oil') }}">Base Oil</a></li>
    <li><a href="{{ route('premium-motor-spirit') }}">Premium Motor Spirit (PMS)</a></li>
    <li><a href="{{ route('automotive-gas-oil') }}">Automotive Gas Oil (AGO)</a></li>
    <li><a href="{{ route('high-density-polyethylene') }}">High-Density Polyethylene (HDPE)</a></li>
    <li><a href="{{ route('low-density-polyethylene') }}">Low-Density Polyethylene (LDPE)</a></li>
    <li><a href="{{ route('polypropylene') }}">Polypropylene (PP)</a></li>
    <li><a href="{{ route('polyethylene-terephthalate') }}">Polyethylene Terephthalate (PET)</a></li>
    <li><a href="{{ route('blow-molding') }}">Blow Molding Accessories</a></li>
    <li><a href="{{ route('low-pour-fuel-oil') }}">Low Pour Fuel Oil (LPFO)</a></li>
    <li><a href="{{ route('marine-diesel-oil') }}">Marine Diesel Oil (MDO)</a></li>
    <li><a href="{{ route('recycling-machine') }}">Recycling Machines</a></li>
    <li><a href="{{ route('used-lubricants') }}">Used Lubricants</a></li>
