<div class="footer-bottom">
				<div class="clearfix">
					<div class="pull-left">

						<div class="copyright">&copy; 2024 ManutradePro - All rights reserved. <a href="#">Ovarle Digitals</a></div>
					</div>
					<div class="pull-right">
						<ul class="footer-nav">
							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Cookie Policy</a></li>
						</ul>
					</div>
				</div>
			</div>